<?php

declare (strict_types=1);
namespace Rector\Core\Exception;

use Exception;
final class VersionException extends Exception
{
}
