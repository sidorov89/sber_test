<?php

declare (strict_types=1);
namespace Rector\Core\Exception;

use Exception;
final class NotImplementedYetException extends Exception
{
}
