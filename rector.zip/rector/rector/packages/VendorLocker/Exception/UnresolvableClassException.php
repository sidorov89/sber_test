<?php

declare (strict_types=1);
namespace Rector\VendorLocker\Exception;

use Exception;
final class UnresolvableClassException extends Exception
{
}
